package clase6;
import java.util.Scanner;
public class contador_main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
    int count=0; //variable contadora
    
    while(count <6) {
    	count=count+3;
    	System.out.println(count);
    }
	}

}
