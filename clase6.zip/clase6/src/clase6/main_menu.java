package clase6;

import java.util.Scanner;

public class main_menu {
// metodos
	public static void Clear() {
		for(int i=1; i<=20; i++) {
			System.out.println("");
		}
	}
	public static void main(String[] args) {
 Scanner tc = new Scanner(System.in);
 int op; //opciones
 boolean exit=false;

while(!exit) {
	System.out.println("1. Opcion compras");
	System.out.println("2. Opcion ventas");
	System.out.println("3. Opcion catalogos");
	System.out.println("4. Exit");
	System.out.println("Ingrese una opcion");
op=tc.nextInt();

switch(op) {
case 1:
	System.out.println("***********************************");
	System.out.println("Ha ingresado al menu de compras");
	System.out.println("***********************************");

break;

case 2:
	System.out.println("*******************************");
	System.out.println("Ha ingresado al menu de ventas");
	System.out.println("*******************************");

break;
case 3:
	System.out.println("********************************");
	System.out.println("Ha ingresado al menu de catalogos");
	System.out.println("*********************************");
case 4:
	exit= true;
	System.out.println("Adios!");
	break;
default:
	System.out.println("Opciones invalidas");
 break;

}

}
	}

}
