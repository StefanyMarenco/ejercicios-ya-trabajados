package clase6;

import java.util.Scanner;
import java.util.StringTokenizer;

public class mainpalabra {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
    Scanner tc= new Scanner(System.in);
    String palabra;
    System.out.println("Ingrese una palabra");
    palabra=tc.nextLine();
    StringTokenizer st=new StringTokenizer(palabra);
    System.out.println("Numero de palabras es:"+st.countTokens());
    
	}

}
