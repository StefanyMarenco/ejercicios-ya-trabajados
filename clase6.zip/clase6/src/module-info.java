/**
 * 
 */
/**
 * @author CCBB-22
 *
 */
module clase6 {
}