package tarea;
import java.util.Scanner;
public class main_pares_impares {
	public static void main(String[] args) {
		Scanner tc= new Scanner(System.in);
		int numeros=0;
		int n=0;
		
		for(int a=0; a<n; a++) {
		System.out.println("Ingrese los numeros");
		numeros=tc.nextInt();
		}
		
		if(numeros%2==0) {
			System.out.println("***********************");
			System.out.println("ESTOS NÚMEROS SON PARES");
			System.out.println("***********************");
		}
		else {
			System.out.println("*************************");
			System.out.println("ESTOS NÚMEROS SON IMPARES");
			System.out.println("*************************");
		}
	}

}
