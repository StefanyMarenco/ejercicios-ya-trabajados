package clase4;
import java.util.Scanner;
public class main_alumnos {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner tc= new Scanner(System.in);
    float nota1;
    float nota2;
    float nota3;
    float promedio1=0, promedio2=0;
    String alumno1, alumno2;
    
    System.out.println("Ingrese el nombre del primer alumno");
    alumno1=tc.nextLine();
    System.out.println("Ingrese el nombre del segundo alumno");
    alumno2=tc.nextLine();
    
    for(int a=1; a<=3; a++) {
    	System.out.println("Ingrese la nota de" +alumno1+"["+a+"]"); 
    	nota1=tc.nextFloat();
    	promedio1=(nota1 +  nota1 + nota1)/3;
    }
    
    for(int b=1; b<=3; b++) {
    	System.out.println("Ingrese la nota de" +alumno2+"["+b+"]");
    	nota2=tc.nextFloat();
    	promedio2=(nota2 + nota2 + nota2)/3;
    }
      System.out.println("El promedio de"+alumno1+ "es"+promedio1);
      System.out.println("El promedido de"+alumno2+ "es"+promedio2);
	}

}
