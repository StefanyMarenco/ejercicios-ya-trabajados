package numeropar;
import java.util.Scanner;
public class main2 {

	public static void main(String[] args) {
		// Nos ayudara a saber cuando es un numero par
	Scanner teclado=new Scanner(System.in);
	
	int numero;
	System.out.print("Ingrese cualquier numero");
	numero=teclado.nextInt();
	
	if(numero%2==0) {
		System.out.println("Este numero es par");
		
	}
	else {
		System.out.println("Este numero es impar");
	  }

	}

}
