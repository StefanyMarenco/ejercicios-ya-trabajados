package operadore;
import java.util.Scanner;
public class main {

	public static void main(String[] args) {
		// Este es un programa que determina que tipo de triangulo es 
		// de acuerdo a sus lados
  Scanner teclado=new Scanner(System.in);
  
    int m,n,p;
    System.out.println("Ingrese el lado#1");
    m=teclado.nextInt();
    System.out.println("Ingrese el lado#2");
    n=teclado.nextInt();	
    System.out.println("Ingrese el lado#3");
    p=teclado.nextInt();	
    
    while( m<=0 || n<=0 || p<=0);
    
    if(m==n && n==p) {
    	System.out.println("El triangulo es un equilatero");
    }
    else if(m==n || n==p || m==p) {
    	System.out.println("El triangulo es un isosceles");
    }
    else {
    	System.out.println("El triangulo es un escaleno");
      }
	}

}
