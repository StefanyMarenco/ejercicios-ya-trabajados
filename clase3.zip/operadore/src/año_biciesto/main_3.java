package año_biciesto;
import java.util.Scanner;
public class main_3 {

	public static void main(String[] args) {
	 Scanner teclado= new Scanner(System.in);
	 
	 int año;
	 System.out.println("Ingrese un año");
	 año=teclado.nextInt();

	 if(año%4==0 && año%100==0) {
		 System.out.println("Este año es biciesto");
	 }
	 else {
		 System.out.println("Este año no es bicesto");
	  }
	}

}
