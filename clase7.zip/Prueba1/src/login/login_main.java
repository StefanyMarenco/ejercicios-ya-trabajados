package login;
import java.util.Scanner;
public class login_main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner input= new Scanner(System.in);
    String Usuario="Maria Prado";
    String Contraseña="abcde";
    String pass=" ";
    int count=0;
    
    while(count<=3) {
      System.out.println("Ingrese el nombre de usuario");
      Usuario=input.nextLine();
    
      System.out.println("Ingrese su contraseña");
      Contraseña=input.nextLine();
      
      if(Usuario.equals("Maria Prado")&& Contraseña.equals(pass)==false) {
    	  
    	System.out.println("Su usuario y contraseña son correctas");
    	return;
      }
    else {
    	  count++;
    	  System.out.println("El usuario o contraseña son incorrectas verifique de nuevo" +count+"de 3");
    	  
        }
      }
    System.out.println("Ya ha fallado varios intentos.Espere unos minutos y vuelva a intentarlo");
      }
	}
    
    
    
	


