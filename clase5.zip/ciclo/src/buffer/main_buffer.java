package buffer;
import java.io.BufferedReader;
import java.io.InputStreamReader;
public class main_buffer {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a, b, c;
		String tecla;
		BufferedReader tc=new Scanner(new InputSreamrReader(System.in));
		
		
	}

}
