package ciclo;
import java.util.Scanner;

public class main_ciclo {
	
	}


