package operacionesmatematicas;
import java.util.Scanner;
public class Operaccione_main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner tc= new Scanner(System.in);
int opcion;
int suma=0;
int resta=0;
int multiplicacion;
float division;
int x=0, y=0;

    System.out.println("\n Ingrese una opcion");
    opcion=tc.nextInt();
    switch(opcion) {
    case 1:
    	System.out.println("Suma");
    	System.out.println("Ingrese el #1");
    	x=tc.nextInt();   
    	System.out.println("Ingrese el #2");
    	y=tc.nextInt();
    	suma=x+y;
    	break;
    case 2:
    	System.out.println("Resta");
    	System.out.println("Ingrese el #1");
    	x=tc.nextInt();   
    	System.out.println("Ingrese el #2");
    	y=tc.nextInt();
    	resta=x-y;
    	break;
    case 3:
    	System.out.println("Multiplicacion");
    	System.out.println("Ingrese el #1");
    	x=tc.nextInt();   
    	System.out.println("Ingrese el #2");
    	y=tc.nextInt();
    	multiplicacion=x*y;
    	break;
    case 4:
    	System.out.println("Divison");
    	System.out.println("Ingrese el #1");
    	x=tc.nextInt();   
    	System.out.println("Ingrese el #2");
    	y=tc.nextInt();
    	division=x/y;
    	break;
    	default:
    		
    	
    }
	}

}
